<?php
$con = mysqli_connect('127.0.0.1','root','');
if(!$con)
{
	echo 'not connected to server';
}
if(!mysqli_select_db($con,'college_register'))
{
	echo 'database not selected';
}

$course_name = $_POST['course_name'];
$course_duration = $_POST['course_duration'];
$fee_structure = $_POST['fee_structure'];
$compulsory_subject = $_POST['compulsory_subject'];
$cut_off = $_POST['cut_off'];
$college_name = $_POST['college_name'];
// connect to the database
$sql = " INSERT INTO course_addition(course_name,course_duration,fee_structure, compulsory_subject,cut_off,college_name) VALUES ('$course_name','$course_duration','$fee_structure','$compulsory_subject','$cut_off','$college_name')";

if(!mysqli_query($con,$sql))
{
	echo ' not inserted';
}
else
{
	echo 'inserted';
		//header("location: /home.php");
    echo("<script language=\"javascript\">");
	echo("top.location.href=\"home.php\";");
	echo("</script>");
} 
header("refresh:2; url=course_addition.html");
 
?>
