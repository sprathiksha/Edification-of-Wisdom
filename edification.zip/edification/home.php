<!DOCTYPE html>
<html>
<head>
	<title>DROPDOWN MENU</title>
	<link rel="stylesheet" type="text/css" href="home.css">
</head>
<body>

<nav class="navi">
	<ul class="menu">
		<li class="menu_items"><a href="home.html"> HOME</a></li>
		<!--<li class="menu_items"><a href="#"> course</a>
		<ul class="submenu">
			<li class="submenu_item"><a href="#">BCA</a></li>
			<li class="submenu_item"><a href="#">BBA</a></li>
			<li class="submenu_item"><a href="#">B.COM</a></li>
        </ul>		
		</li>
		-->
		
		<li class="menu_items"><a href="#"> COMMERCE</a>
		<ul class="submenu">
			<li class="submenu_item"><a href="bcom_main.html">B.COM</a></li>
			<li class="submenu_item"><a href="bba_main.html">BBA</a></li>
			<li class="submenu_item"><a href="MCOM_main.html">M.COM</a></li>
        </ul>	
		
		</li>
		<li class="menu_items"><a href="#"> SCIENCE</a>
		<ul class="submenu">
			<li class="submenu_item"><a href="BSC_main.html">B.SC</a></li>
			<li class="submenu_item"><a href="MSC_main.html">M.SC</a></li>
        </ul>	
		</li>
		<li class="menu_items"><a href="#"> ENGINEERING</a>
		<ul class="submenu">
			<li class="submenu_item"><a href="BE_main.html">BE</a></li>
			<li class="submenu_item"><a href="btech_main.html">B.TECH</a></li>
			<li class="submenu_item"><a href="#">ME</a></li>
			<li class="submenu_item"><a href="mtech_main.html">M.TECH</a></li>
        </ul>	
		</li>
		<li class="menu_items"><a href="#"> LAW</a>
		<ul class="submenu">
			<li class="submenu_item"><a href="LLB_main.html">LLB</a></li>
			<li class="submenu_item"><a href="#">LLD</a></li>
			<li class="submenu_item"><a href="LLM_main.html">LLM</a></li>
        </ul>	
		</li>
		<li class="menu_items"><a href="#"> MEDICAL</a>
		<ul class="submenu">
			<li class="submenu_item"><a href="#">BAMS</a></li>
			<li class="submenu_item"><a href="BSC_main.html">B.SC</a></li>
			<li class="submenu_item"><a href="#">BHMS</a></li>
			<li class="submenu_item"><a href="bpt_main.html">BPT</a></li>
        </ul>	
		</li>
		<li class="menu_items"><a href="#"> ARTS</a>
		<ul class="submenu">
			<li class="submenu_item"><a href="BA_main.html">BA</a></li>
			<li class="submenu_item"><a href="BFA_main.html">BFA</a></li>
			<li class="submenu_item"><a href="MA_main.html">MA</a></li>
			<li class="submenu_item"><a href="MPHIL_main.html">M.PHIL</a></li>
			<li class="submenu_item"><a href="PHD_main.html">PH.D</a></li>
        </ul>	
		</li>
		 
		<li class="menu_items"><a href="#"> MORE</a>
		<ul class="submenu">
			<li class="submenu_item"><a href="#">ARGRICULTURE</a></li>
			<li class="submenu_item"><a href="#">ARCHITECTURE</a></li>
			<li class="submenu_item"><a href="#">DENTAL</a></li>
			<li class="submenu_item"><a href="#">DESIGN</a></li>
			<li class="submenu_item"><a href="#">HOTEL MANAGEMENT</a></li>
        </ul>	
		</li>
		
		<li class="menu_items"><a href="search_criteria.php"> search</a>
	</li>
			<li class="menu_items"><a href="logout.php"> logout</a>
	</li>
	<link rel="stylesheet" href="https://cdn.linearicons.com/free/1.0.0/icon-font.min.css">


    </ul>
</nav>
</body>
</html>
