<?php
$con = mysqli_connect('127.0.0.1','root','');
if(!$con)
{
	echo 'not connected to server';
}
if(!mysqli_select_db($con,'college_register'))
{
	echo 'database not selected';
}

$college_Name = $_POST['college_Name'];
$representative_Name = $_POST['representative_Name'];
$representative_Post = $_POST['representative_Post'];
$Mobile_Number = $_POST['Mobile_Number'];
$registration_Number = $_POST['registration_Number'];
$College_url = $_POST['College_url'];
$registration_date = $_POST['registration_date'];
$Rep_email_Id = $_POST['Rep_email_Id'];
$location = $_POST['location'];
$City = $_POST['City'];
$Pin_Code = $_POST['Pin_Code'];
$State = $_POST['State'];
$Country = $_POST['Country'];


$sql = " INSERT INTO registrationn(college_Name, representative_Name, representative_Post, Mobile_Number, registration_Number, College_url, registration_date, Rep_email_Id, location, City, Pin_Code, State, Country) VALUES ('$college_Name', '$representative_Name', '$representative_Post', '$Mobile_Number', '$registration_Number', '$College_url', '$registration_date', '$Rep_email_Id', '$location', '$City', '$Pin_Code', '$State', '$Country')";

if(!mysqli_query($con,$sql))
{
	echo ' not inserted';
}
else
{
	echo 'inserted';

	echo("<script language=\"javascript\">");
	echo("top.location.href=\"course_addition.html\";");
	echo("</script>");

} 
header("refresh:2; url=college_register.html");

?>

