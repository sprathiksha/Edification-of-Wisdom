<?php
$college_Name = $_POST['college_Name'];
$representative_Name = $_POST['representative_Name'];
$representative_Post = $_POST['representative_Post'];
$Mobile_Number = $_POST['Mobile_Number'];
$registration_Number = $_POST['registration_Number'];
$College_url = $_POST['College_url'];
$registration_day = $_POST['registration_day'];
$registration_Month = $_POST['registration_Month'];
$registration_Year = $_POST['registration_Year'];
$Rep_email_Id = $_POST['Rep_email_Id'];
$location = $_POST['location'];
$City = $_POST['City'];
$Pin_Code = $_POST['Pin_Code'];
$State = $_POST['State'];
$Country = $_POST['Country'];
if (!empty($college_Name) || !empty($representative_Name) || !empty($representative_Post) || !empty($Mobile_Number) || !empty($registration_Number) || !empty($College_url) || !empty($registration_day) || !empty($registration_Month) || !empty($registration_Year) || !empty($Rep_email_Id) || !empty($location) || !empty($City) || !empty($Pin_Code) || !empty($State) || !empty($Country)){
 $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "college_register";
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    if (mysqli_connect_error()) {
     die('Connect Error('. mysqli_connect_errno().')'. mysqli_connect_error());
    } else {
     $SELECT = "SELECT email From registrationn Where email = ? Limit 1";
     $INSERT = "INSERT Into registrationn (college_Name, representative_Name, representative_Post, Mobile_Number, registration_Number, College_url, registration_day, registration_Month, registration_Year, Rep_email_Id, location, City, Pin_Code, State, Country) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )";
     //Prepare statement
     prepare($SELECT);
$stmt->bind_param("s", Rep_email_Id);
$stmt->execute();
$stmt->bind_result(Rep_email_Id);
$stmt->store_result();
$rnum = $stmt->num_rows;
if ($rnum==0) {
$stmt->close();
$stmt = $conn->prepare($INSERT);
      $stmt->bind_param("ssssii",$college_Name, $representative_Name, $representative_Post, $Mobile_Number, $registration_Number, $College_url, $registration_day, $registration_Month, $registration_Year, $Rep_email_Id, $location, $City, $Pin_Code, $State, $Country);
      $stmt->execute();
      echo "New record inserted sucessfully";
     } else {
      echo "Someone already register using this email";
     }
     $stmt->close();
     $conn->close();
    }
} else {
 echo "All field are required";
 die();
}
?>