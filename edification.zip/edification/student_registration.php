<?php
$con = mysqli_connect('127.0.0.1','root','');
if(!$con)
{
	echo 'not connected to server';
}
if(!mysqli_select_db($con,'student_registration'))
{
	echo 'database not selected';
}

$First_Name = $_POST['First_Name'];
$Last_Name = $_POST['Last_Name'];
$registration_date = $_POST['registration_date'];
$Email_Id = $_POST['Email_Id'];
$Mobile_Number = $_POST['Mobile_Number'];
$Gender = $_POST['Gender'];
$Address = $_POST['Address'];
$City = $_POST['City'];
$Pin_Code = $_POST['Pin_Code'];
$State = $_POST['State'];
$Country = $_POST['Country'];


$sql = " INSERT INTO register(First_Name, Last_Name, registration_date, Email_Id, Mobile_Number, Gender, Address, City, Pin_Code, State, Country) VALUES ('$First_Name', '$Last_Name', '$registration_date', '$Email_Id', '$Mobile_Number', '$Gender', '$Address', '$City', '$Pin_Code', '$State', '$Country')";

if(!mysqli_query($con,$sql))
{
	echo ' not inserted';
}
else
{
	echo 'inserted';
	echo("<script language=\"javascript\">");
	echo("top.location.href=\"home.php\";");
	echo("</script>");
} 
header("refresh:2; url=student_registration.html");

?>

